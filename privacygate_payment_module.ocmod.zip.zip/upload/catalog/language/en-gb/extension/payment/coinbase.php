<?php

$_['text_title'] = 'PrivacyGate <a href="https://privacygate.io/" target="_blank" rel="noopener">(Learn more)</a>';
$_['button_confirm'] = 'Pay with PrivacyGate';
